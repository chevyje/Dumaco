import Navbar from "../components/navbar.jsx";
import Sidebar from "../components/sidebar.jsx";
import Collapse from "../components/collapse.jsx";


function klantOverzicht() {
    return(
        <>
            <Navbar/>
            <Sidebar />
            <Collapse />
        </>
    )
}

export default klantOverzicht()
